# Udacity frontend Neighborhood Map Project
This app is developed to display a google map of a particular region(my current residing place) and showcase some of it's nearby places

## Code
CSS - One file makes up the css for handling all the styles
- `mapStyles.css` (Overwrites Bootstrap CSS for custom styling of app)

JS - There are quite a few here and I will try explain as best as possible without becoming too convoluted.
- `knockout-3.4.2.js` (Knockout framework)
- `app.js` (Main application file)
- `locations.js` (Contains 5 neighborhood location in a list to populate the map)
- `manipulation.js` (used for sidebar navigation to display filter for neighborhood places used)

HTML - `index.html` is where all the data is binded.

## Features
A Google Maps implemenation that shows you some of the neighbourhood places of the location where I am working currently(SIPCOT IT Park, Siruseri)
The site is fully responsive and will run on your tiniest screens all the way to the largest screen you can think of.
You get a full screen Google Map, populated with my favorite locations, along with a sidebar with a list of the locations that can be clicked on and also filtered so you can nail down what you want without any other distractions.

## APIs
Google Maps API is used here to show the map and generate the markers etc.
Foursquare API is used to pull more information on my favorite locations and provide a more complete listing when you click on the marker and the infoWindow shows up.
