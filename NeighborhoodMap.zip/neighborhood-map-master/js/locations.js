var myNeighBorHoodLocs = [
    {
        locName: 'Capgemini Pvt. Ltd.',
        latitude: 12.822775,
        longitude:  80.221835,
        type: 'Company Office'
    },
	{	
		locName: 'TCS, Siruseri',
        latitude: 12.829532,
        longitude:  80.217806,
        type: 'Company Office'
	},
	{
		locName: 'AGS Cinemas',
        latitude: 12.850892,
        longitude:  80.225633,
        type: 'Shopping/Movie'
	},
	{
		locName: 'OMR Food Street',
        latitude: 12.848575 ,
        longitude:  80.226355,
        type: 'Food'
	},
	{
		locName: 'Radiance Ivy Terrace',
        latitude: 12.837922,
        longitude:  80.229380,
        type: 'Apartments'	
	}, 
	{
		locName: 'Cognizant Office',
        latitude: 12.825287,
        longitude:  80.219734,
        type: 'Company Office'	
	},
	{
		locName: 'HDFC Bank',
        latitude: 12.833708,
        longitude:  80.228896,
        type: 'Bank'
	}
]