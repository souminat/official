// Global variable for the entire mapcanvas
var mapContent;
//GLobal variable for accessing location details with FourSquare API
var clientID, clientSecret;
function loadApp() {
    ko.bindMap(new NeighborHoodMap());
}

function NeighborHoodMap() {
    var mapObj = this;

    mapObj.searchList = ko.loadNeighborHoodList("");
    mapObj.placeList = [];
	
	//This function allows to load a map with central coordinates of a place whosenearby locations are to be tracked
	//This function also allows to load all the place details from myNeighBorHoodLocs list
	 mapObj.initMap = function() {
        var centralLoc = document.getElementById('map');
        var  locCoordintes = {
            center: new google.maps.LatLng(12.829529,80.204422),
            zoom: 15
        };
        // Creates a new map with zoom and center with Google Map API
        mapContent = new google.maps.Map(centralLoc, locCoordintes);

        // Set the addressWindow
        mapObj.addressWindow = new google.maps.InfoWindow();
        for (var loc in myNeighBorHoodLocs) {
            mapObj.markerTitle = myNeighBorHoodLocs[loc].locName;
            mapObj.markerLat = myNeighBorHoodLocs[loc].latitude;
            mapObj.markerLng = myNeighBorHoodLocs[loc].longitude;
            
			// setting the marker with Google Map
            mapObj.place = new google.maps.Marker({
                map: mapContent,
                position: {
                    lat: mapObj.markerLat,
                    lng: mapObj.markerLng
                },
                title: mapObj.markerTitle,
                lat: mapObj.markerLat,
                lng: mapObj.markerLng,
				id: loc,
                animation: google.maps.Animation.DROP
            });
            mapObj.place.setMap(mapContent);
            mapObj.placeList.push(mapObj.place);
            mapObj.place.addListener('click', mapObj.showNeighborHoodLocations);
        }
    };

	//This function generates the animation that allows user to click on a location balloon and populate it's data displaying address details
	mapObj.showNeighborHoodLocations = function() {
        mapObj.popAddressBalloon(this, mapObj.addressWindow);
        mapObj.setAnimation(google.maps.Animation.BOUNCE);
        setTimeout((function() {
            this.setAnimation(null);
        }).bind(this), 800);
    };
	
	mapObj.initMap();
	
	

    // This block appends our locations to a list using a data-bind and and also works as a filter to search for those locations
    mapObj.neighborhoodPlaces = ko.calculateLoc(function() {
        var filterList = [];
        for (var filter in mapObj.placeList) {
            var markerLocation = mapObj.placeList[filter];
			
			filterList.push(markerLocation.title.toLowerCase().includes(mapObj.searchList()
                    .toLowerCase())?markerLocation: null);
			
			 mapObj.placeList[filter].setVisible((filterList[filter] == markerLocation)?true : false);
        }
        return filterList;
    }, this);
	
	//This function loads all the neighborhood places with their address details specified in myNeighBorHoodLocs List using FourSquare API
    mapObj.popAddressBalloon = function(place, infowindow) {
        if (infowindow.marker != place) {
            infowindow.setContent('');
            infowindow.marker = place;
            // Foursquare API Client
            clientID = "Q4A3LCEGZJAPO2O2HTCDV0YOE3P4MZ1Z0IV0P4KS1IUJYQIX";
            clientSecret =
                "QVNFFHE2PI1NFDAAGVG311X24NLYRJUMKLNTHRI2MVWCO22I";
            // URL for Foursquare API
            var locUrl = 'https://api.foursquare.com/v2/venues/search?ll=' +
                place.lat + ',' + place.lng + '&client_id=' + clientID +
                '&client_secret=' + clientSecret + '&query=' + place.title +
                '&v=20170708' + '&m=foursquare';
            // Foursquare API
            $.getJSON(locUrl).done(function(place) {
				//getting the JSON response for a particular location's address details
                var response = place.response.venues[0];
                mapObj.road = response.location.formattedAddress[0];
                mapObj.city = response.location.formattedAddress[1];
                mapObj.pin = response.location.formattedAddress[3];
                mapObj.country = response.location.formattedAddress[4];
                mapObj.type = response.categories[0].shortName;

				//setting address details like street,city,postal code,country & place type
                mapObj.htmlContentFoursquare =
                    '<h5 class="iw_subtitle">(' + mapObj.type +
                    ')</h5>' + '<div>' +
                    '<h6 class="iw_address_title"> Address: </h6>' +
                    '<p class="iw_address">' + mapObj.road + '</p>' +
                    '<p class="iw_address">' + mapObj.city + '</p>' +
                    '<p class="iw_address">' + mapObj.pin + '</p>' +
                    '<p class="iw_address">' + mapObj.country +
                    '</p>' + '</div>' + '</div>';

                infowindow.setContent(mapObj.htmlContent + mapObj.htmlContentFoursquare);
            }).fail(function() {
                // Send alert
                alert(
                    "There was an issue loading the Foursquare API. Please refresh your page to try again."
                );
            });

            mapObj.htmlContent = '<div>' + '<h4 class="iw_title">' + place.title +
                '</h4>';

            infowindow.open(mapContent, place);

            infowindow.addListener('closeclick', function() {
                infowindow.marker = null;
            });
        }
    };
}

locNotFound = function googleError() {
    alert(
        'Error in loading google maps! Please refresh and try again...'
    );
};

